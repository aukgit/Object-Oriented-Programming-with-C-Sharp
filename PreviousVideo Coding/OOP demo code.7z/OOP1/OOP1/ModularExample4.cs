﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
 * Written by Alim Ul Karim
 * mailto: alim@developers-organism.com
 * developers-organism.com
 * find us on fb.com/developersOrganism
 * */
namespace OOP1 {
    public class ModularExample4 : ITest {
        #region ITest Members

        public void Test() {
            throw new NotImplementedException();
        }

        public int Example(decimal x, double y) {
            throw new NotImplementedException();
        }

        #endregion
    }
}
