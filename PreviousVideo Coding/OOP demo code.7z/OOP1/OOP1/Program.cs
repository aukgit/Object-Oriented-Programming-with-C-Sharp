﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//using OOP1.Inheritance;
using OOP1.Polymorphism;
using OOP1.ExtensionMethod;
using OOP1.Inheritance;
using OOP1.Interfaces;
/*
 * Written by Alim Ul Karim
 * mailto: alim@developers-organism.com
 * developers-organism.com
 * find us on fb.com/developersOrganism
 * */
namespace OOP1 {
    class Program {
        public static void Main(string[] args) {
            #region Vector generics
            var vector = new VectorGenerics<string,int>(200);
            vector.Add("hello");
            vector.Add("123");
            vector.Add("423");
            vector.PrintAll();
            #endregion
            //Console.WriteLine("Hello World");
            Console.ReadKey();
        }

    }
}
