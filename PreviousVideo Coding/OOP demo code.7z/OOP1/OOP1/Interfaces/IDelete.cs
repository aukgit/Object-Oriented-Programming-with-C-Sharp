﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
/*
 * Written by Alim Ul Karim
 * mailto: alim@developers-organism.com
 * developers-organism.com
 * find us on fb.com/developersOrganism
 * */
namespace OOP1.Interfaces {
    public interface IDelete {
        int Deleted {
            get;
            set;
        }

        void Delete();
    }
}
